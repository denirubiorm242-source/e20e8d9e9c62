# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(rentRoll src/rentRoll.cpp)
set_property(TARGET rentRoll PROPERTY CXX_STANDARD 11)
target_link_libraries(rentRoll lionss pthread)

add_executable(tenancyShard src/tenancyShard.cpp)
set_property(TARGET tenancyShard PROPERTY CXX_STANDARD 11)
target_link_libraries(tenancyShard lionss pthread)

add_executable(cidr-aggregate src/cidr-aggregate.cpp)
set_property(TARGET cidr-aggregate PROPERTY CXX_STANDARD 11)
target_link_libraries(cidr-aggregate lionss pthread)

add_executable(chash_ring src/chash_ring.cpp)
set_property(TARGET chash_ring PROPERTY CXX_STANDARD 11)
target_link_libraries(chash_ring lionss pthread)

add_executable(tz_recalc src/tz_recalc.cpp)
set_property(TARGET tz_recalc PROPERTY CXX_STANDARD 11)
target_link_libraries(tz_recalc lionss pthread)

add_executable(ansible_check src/ansible_check.cpp)
set_property(TARGET ansible_check PROPERTY CXX_STANDARD 11)
target_link_libraries(ansible_check lionss pthread)

add_executable(lupine src/lupine.cpp)
set_property(TARGET lupine PROPERTY CXX_STANDARD 11)
target_link_libraries(lupine lionss pthread)

add_executable(gnss-ppp src/gnss-ppp.cpp)
set_property(TARGET gnss-ppp PROPERTY CXX_STANDARD 11)
target_link_libraries(gnss-ppp lionss pthread)

add_executable(fjord src/fjord.cpp)
set_property(TARGET fjord PROPERTY CXX_STANDARD 11)
target_link_libraries(fjord lionss pthread)

add_executable(pixelupscale src/pixelupscale.cpp)
set_property(TARGET pixelupscale PROPERTY CXX_STANDARD 11)
target_link_libraries(pixelupscale lionss pthread)

add_executable(vole src/vole.cpp)
set_property(TARGET vole PROPERTY CXX_STANDARD 11)
target_link_libraries(vole lionss pthread)

add_executable(limsBatch src/limsBatch.cpp)
set_property(TARGET limsBatch PROPERTY CXX_STANDARD 11)
target_link_libraries(limsBatch lionss pthread)

add_executable(raven src/raven.cpp)
set_property(TARGET raven PROPERTY CXX_STANDARD 11)
target_link_libraries(raven lionss pthread)

add_executable(thermal-enclosure src/thermal-enclosure.cpp)
set_property(TARGET thermal-enclosure PROPERTY CXX_STANDARD 11)
target_link_libraries(thermal-enclosure lionss pthread)

add_executable(xcompile-riscv src/xcompile-riscv.cpp)
set_property(TARGET xcompile-riscv PROPERTY CXX_STANDARD 11)
target_link_libraries(xcompile-riscv lionss pthread)

add_executable(iris src/iris.cpp)
set_property(TARGET iris PROPERTY CXX_STANDARD 11)
target_link_libraries(iris lionss pthread)

add_executable(isochrone_15 src/isochrone_15.cpp)
set_property(TARGET isochrone_15 PROPERTY CXX_STANDARD 11)
target_link_libraries(isochrone_15 lionss pthread)

add_executable(wifiHeatmap src/wifiHeatmap.cpp)
set_property(TARGET wifiHeatmap PROPERTY CXX_STANDARD 11)
target_link_libraries(wifiHeatmap lionss pthread)

add_executable(juniper src/juniper.cpp)
set_property(TARGET juniper PROPERTY CXX_STANDARD 11)
target_link_libraries(juniper lionss pthread)

add_executable(lumen_cache src/lumen_cache.cpp)
set_property(TARGET lumen_cache PROPERTY CXX_STANDARD 11)
target_link_libraries(lumen_cache lionss pthread)

add_executable(Cinder src/Cinder.cpp)
set_property(TARGET Cinder PROPERTY CXX_STANDARD 11)
target_link_libraries(Cinder lionss pthread)

add_executable(BarleyYield src/BarleyYield.cpp)
set_property(TARGET BarleyYield PROPERTY CXX_STANDARD 11)
target_link_libraries(BarleyYield lionss pthread)

add_executable(mqtt-broker-bench src/mqtt-broker-bench.cpp)
set_property(TARGET mqtt-broker-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(mqtt-broker-bench lionss pthread)

add_executable(timesheet-audit src/timesheet-audit.cpp)
set_property(TARGET timesheet-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(timesheet-audit lionss pthread)

add_executable(yew src/yew.cpp)
set_property(TARGET yew PROPERTY CXX_STANDARD 11)
target_link_libraries(yew lionss pthread)

add_executable(voxelforge src/voxelforge.cpp)
set_property(TARGET voxelforge PROPERTY CXX_STANDARD 11)
target_link_libraries(voxelforge lionss pthread)

add_executable(PcbDefect src/PcbDefect.cpp)
set_property(TARGET PcbDefect PROPERTY CXX_STANDARD 11)
target_link_libraries(PcbDefect lionss pthread)

add_executable(fontforge-batch src/fontforge-batch.cpp)
set_property(TARGET fontforge-batch PROPERTY CXX_STANDARD 11)
target_link_libraries(fontforge-batch lionss pthread)

add_executable(cite_check src/cite_check.cpp)
set_property(TARGET cite_check PROPERTY CXX_STANDARD 11)
target_link_libraries(cite_check lionss pthread)

add_executable(birch src/birch.cpp)
set_property(TARGET birch PROPERTY CXX_STANDARD 11)
target_link_libraries(birch lionss pthread)

