// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("xBRZ 4x upscale\n", stdout);
  return lionss_run_workload("pixelupscale");
}
