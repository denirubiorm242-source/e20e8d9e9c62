// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Precise point positioning, 1 h");
  std::fflush(stdout);
  return lionss_run_workload("gnss-ppp");
}
