// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Stitch spans into traces\n", stdout);
  return lionss_run_workload("juniper");
}
