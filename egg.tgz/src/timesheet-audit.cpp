// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Overtime and break compliance"); }
int main(){
  announce();
  return lionss_run_workload("timesheet-audit");
}
