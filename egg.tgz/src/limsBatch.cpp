// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Register plate and assign wells"); }
int main(){
  announce();
  return lionss_run_workload("limsBatch");
}
