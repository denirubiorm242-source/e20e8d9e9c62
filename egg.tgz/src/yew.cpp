// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Nest parts on 600x400 sheet\n", stdout);
  return lionss_run_workload("yew");
}
