// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Verify citation formats");
  std::fflush(stdout);
  return lionss_run_workload("cite_check");
}
