// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Interpolate coverage map"); }
int main(){
  announce();
  return lionss_run_workload("wifiHeatmap");
}
