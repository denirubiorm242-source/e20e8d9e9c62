// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "1k publishers, QoS 1");
  std::fflush(stdout);
  return lionss_run_workload("mqtt-broker-bench");
}
