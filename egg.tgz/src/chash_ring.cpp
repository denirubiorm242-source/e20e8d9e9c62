// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("150 vnodes, key distribution\n", stdout);
  return lionss_run_workload("chash_ring");
}
