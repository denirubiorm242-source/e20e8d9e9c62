// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Detect solder bridges"); }
int main(){
  announce();
  return lionss_run_workload("PcbDefect");
}
