// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Aggregate to minimal prefixes"); }
int main(){
  announce();
  return lionss_run_workload("cidr-aggregate");
}
