// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cross-compile and run under qemu"); }
int main(){
  announce();
  return lionss_run_workload("xcompile-riscv");
}
