// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fit response curve\n", stdout);
  return lionss_run_workload("BarleyYield");
}
