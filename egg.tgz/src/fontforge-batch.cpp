// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Hint glyph outlines\n", stdout);
  return lionss_run_workload("fontforge-batch");
}
